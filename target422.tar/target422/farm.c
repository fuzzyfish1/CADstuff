/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_295(unsigned x)
{
    return x + 2425393224U;
}

unsigned addval_199(unsigned x)
{
    return x + 3347663019U;
}

void setval_196(unsigned *p)
{
    *p = 3284633928U;
}

void setval_264(unsigned *p)
{
    *p = 2455293560U;
}

unsigned addval_386(unsigned x)
{
    return x + 4072902744U;
}

unsigned getval_284()
{
    return 3277359500U;
}

unsigned addval_421(unsigned x)
{
    return x + 3284631880U;
}

void setval_180(unsigned *p)
{
    *p = 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_465(unsigned x)
{
    return x + 2430634344U;
}

void setval_198(unsigned *p)
{
    *p = 2425542281U;
}

unsigned getval_394()
{
    return 3675838089U;
}

void setval_473(unsigned *p)
{
    *p = 3674789513U;
}

unsigned getval_220()
{
    return 3523789193U;
}

unsigned getval_307()
{
    return 3524837769U;
}

unsigned addval_242(unsigned x)
{
    return x + 2430634312U;
}

void setval_482(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_337()
{
    return 2425411213U;
}

void setval_435(unsigned *p)
{
    *p = 3221799305U;
}

void setval_172(unsigned *p)
{
    *p = 3286272328U;
}

void setval_105(unsigned *p)
{
    *p = 3381969289U;
}

unsigned addval_231(unsigned x)
{
    return x + 3286272840U;
}

unsigned getval_237()
{
    return 3372796569U;
}

void setval_209(unsigned *p)
{
    *p = 3682910633U;
}

void setval_223(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_219(unsigned x)
{
    return x + 3682912905U;
}

unsigned addval_124(unsigned x)
{
    return x + 3373845129U;
}

unsigned addval_313(unsigned x)
{
    return x + 3224950411U;
}

void setval_385(unsigned *p)
{
    *p = 3531917953U;
}

unsigned addval_483(unsigned x)
{
    return x + 3225993609U;
}

unsigned getval_244()
{
    return 3252717896U;
}

void setval_399(unsigned *p)
{
    *p = 3676359304U;
}

unsigned addval_348(unsigned x)
{
    return x + 3531921033U;
}

unsigned addval_149(unsigned x)
{
    return x + 3529556361U;
}

unsigned getval_255()
{
    return 3223898761U;
}

unsigned getval_170()
{
    return 3230976649U;
}

unsigned addval_208(unsigned x)
{
    return x + 3531917961U;
}

void setval_431(unsigned *p)
{
    *p = 3281114761U;
}

unsigned addval_364(unsigned x)
{
    return x + 3402094217U;
}

void setval_247(unsigned *p)
{
    *p = 3677929867U;
}

unsigned addval_279(unsigned x)
{
    return x + 3252717896U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
